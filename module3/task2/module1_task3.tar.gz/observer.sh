#!/bin/bash


CONFIG="observer.conf"
LOG="observer.log"

while read -r SCRIPT; do
	if ! pgrep -f "$SCRIPT" > /dev/null; then
		echo "$(date '+%Y/%m/%d %H:%M:%S') Скрипт $SCRIPT не найден, запуск" >> "$LOG"
		nohup ./$SCRIPT > /dev/null 2>&1 &
	fi
done < "$CONFIG"
