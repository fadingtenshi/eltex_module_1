#!/bin/bash

LOG="report_$(basename $0).log"
BEG_TIME=$(date "+%Y/%m/%d %H:%M:%S")
PID=$$

echo "[PID] $BEG_TIME Скрипт запущен" >> "$LOG"

RAND=$(( RANDOM % 1771 + 30 ))
sleep $RAND

END_TIME=$(date "+%Y/%m/%d %H:%M:%S")
echo "[$PID] $END_TIME Скрипт завершился, работал $(( RAND / 60 )) минут" >> "$LOG"
